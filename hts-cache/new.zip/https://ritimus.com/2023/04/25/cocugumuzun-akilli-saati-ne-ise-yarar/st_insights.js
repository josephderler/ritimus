<!DOCTYPE html>
<html lang="tr" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="https://ritimus.com/xmlrpc.php">

	<title>Sayfa bulunamadı &#8211; Ritimus</title>
<meta name='robots' content='max-image-preview:large' />
<script>window._wca = window._wca || [];</script>
<link rel='dns-prefetch' href='//stats.wp.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Ritimus &raquo; akışı" href="https://ritimus.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Ritimus &raquo; yorum akışı" href="https://ritimus.com/comments/feed/" />
<style id="wp-img-auto-sizes-contain-inline-css">
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<link rel='stylesheet' id='masterstudy-bootstrap-css' href='https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/vendors/bootstrap.min.css?ver=2.8.8' media='all' />
<link rel='stylesheet' id='masterstudy-bootstrap-custom-css' href='https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/vendors/ms-bootstrap-custom.css?ver=2.8.8' media='all' />
<style id="wp-block-library-inline-css">
:root{--wp-block-synced-color:#7a00df;--wp-block-synced-color--rgb:122,0,223;--wp-bound-block-color:var(--wp-block-synced-color);--wp-editor-canvas-background:#ddd;--wp-admin-theme-color:#007cba;--wp-admin-theme-color--rgb:0,124,186;--wp-admin-theme-color-darker-10:#006ba1;--wp-admin-theme-color-darker-10--rgb:0,107,160.5;--wp-admin-theme-color-darker-20:#005a87;--wp-admin-theme-color-darker-20--rgb:0,90,135;--wp-admin-border-width-focus:2px}@media (min-resolution:192dpi){:root{--wp-admin-border-width-focus:1.5px}}.wp-element-button{cursor:pointer}:root .has-very-light-gray-background-color{background-color:#eee}:root .has-very-dark-gray-background-color{background-color:#313131}:root .has-very-light-gray-color{color:#eee}:root .has-very-dark-gray-color{color:#313131}:root .has-vivid-green-cyan-to-vivid-cyan-blue-gradient-background{background:linear-gradient(135deg,#00d084,#0693e3)}:root .has-purple-crush-gradient-background{background:linear-gradient(135deg,#34e2e4,#4721fb 50%,#ab1dfe)}:root .has-hazy-dawn-gradient-background{background:linear-gradient(135deg,#faaca8,#dad0ec)}:root .has-subdued-olive-gradient-background{background:linear-gradient(135deg,#fafae1,#67a671)}:root .has-atomic-cream-gradient-background{background:linear-gradient(135deg,#fdd79a,#004a59)}:root .has-nightshade-gradient-background{background:linear-gradient(135deg,#330968,#31cdcf)}:root .has-midnight-gradient-background{background:linear-gradient(135deg,#020381,#2874fc)}:root{--wp--preset--font-size--normal:16px;--wp--preset--font-size--huge:42px}.has-regular-font-size{font-size:1em}.has-larger-font-size{font-size:2.625em}.has-normal-font-size{font-size:var(--wp--preset--font-size--normal)}.has-huge-font-size{font-size:var(--wp--preset--font-size--huge)}:root .has-text-align-center{text-align:center}:root .has-text-align-left{text-align:left}:root .has-text-align-right{text-align:right}.has-fit-text{white-space:nowrap!important}#end-resizable-editor-section{display:none}.aligncenter{clear:both}.items-justified-left{justify-content:flex-start}.items-justified-center{justify-content:center}.items-justified-right{justify-content:flex-end}.items-justified-space-between{justify-content:space-between}.screen-reader-text{word-wrap:normal!important;border:0;clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;word-break:normal!important}.screen-reader-text:focus{background-color:#ddd;clip-path:none;color:#444;display:block;font-size:1em;height:auto;left:5px;line-height:normal;padding:15px 23px 14px;text-decoration:none;top:5px;width:auto;z-index:100000}html :where(.has-border-color){border-style:solid}html :where([style^=border-color],[style*=";border-color"],[style*="; border-color"]){border-style:solid}html :where([style^=border-top-color],[style*=";border-top-color"],[style*="; border-top-color"]){border-top-style:solid}html :where([style^=border-right-color],[style*=";border-right-color"],[style*="; border-right-color"]){border-right-style:solid}html :where([style^=border-bottom-color],[style*=";border-bottom-color"],[style*="; border-bottom-color"]){border-bottom-style:solid}html :where([style^=border-left-color],[style*=";border-left-color"],[style*="; border-left-color"]){border-left-style:solid}html :where([style^=border-width],[style*=";border-width"],[style*="; border-width"]){border-style:solid}html :where([style^=border-top-width],[style*=";border-top-width"],[style*="; border-top-width"]){border-top-style:solid}html :where([style^=border-right-width],[style*=";border-right-width"],[style*="; border-right-width"]){border-right-style:solid}html :where([style^=border-bottom-width],[style*=";border-bottom-width"],[style*="; border-bottom-width"]){border-bottom-style:solid}html :where([style^=border-left-width],[style*=";border-left-width"],[style*="; border-left-width"]){border-left-style:solid}html :where(img[class*=wp-image-]){height:auto;max-width:100%}:where(figure){margin:0 0 1em}html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:var(--wp-admin--admin-bar--height,0px)}@media screen and (max-width:600px){html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:0px}}

/*# sourceURL=/wp-includes/css/dist/block-library/common.min.css */
</style>
<style id="wp-block-heading-inline-css">
h1:where(.wp-block-heading).has-background,h2:where(.wp-block-heading).has-background,h3:where(.wp-block-heading).has-background,h4:where(.wp-block-heading).has-background,h5:where(.wp-block-heading).has-background,h6:where(.wp-block-heading).has-background{padding:1.25em 2.375em}h1.has-text-align-left[style*=writing-mode]:where([style*=vertical-lr]),h1.has-text-align-right[style*=writing-mode]:where([style*=vertical-rl]),h2.has-text-align-left[style*=writing-mode]:where([style*=vertical-lr]),h2.has-text-align-right[style*=writing-mode]:where([style*=vertical-rl]),h3.has-text-align-left[style*=writing-mode]:where([style*=vertical-lr]),h3.has-text-align-right[style*=writing-mode]:where([style*=vertical-rl]),h4.has-text-align-left[style*=writing-mode]:where([style*=vertical-lr]),h4.has-text-align-right[style*=writing-mode]:where([style*=vertical-rl]),h5.has-text-align-left[style*=writing-mode]:where([style*=vertical-lr]),h5.has-text-align-right[style*=writing-mode]:where([style*=vertical-rl]),h6.has-text-align-left[style*=writing-mode]:where([style*=vertical-lr]),h6.has-text-align-right[style*=writing-mode]:where([style*=vertical-rl]){rotate:180deg}
/*# sourceURL=https://ritimus.com/wp-includes/blocks/heading/style.min.css */
</style>
<style id="wp-block-image-inline-css">
.wp-block-image>a,.wp-block-image>figure>a{display:inline-block}.wp-block-image img{box-sizing:border-box;height:auto;max-width:100%;vertical-align:bottom}@media not (prefers-reduced-motion){.wp-block-image img.hide{visibility:hidden}.wp-block-image img.show{animation:show-content-image .4s}}.wp-block-image[style*=border-radius] img,.wp-block-image[style*=border-radius]>a{border-radius:inherit}.wp-block-image.has-custom-border img{box-sizing:border-box}.wp-block-image.aligncenter{text-align:center}.wp-block-image.alignfull>a,.wp-block-image.alignwide>a{width:100%}.wp-block-image.alignfull img,.wp-block-image.alignwide img{height:auto;width:100%}.wp-block-image .aligncenter,.wp-block-image .alignleft,.wp-block-image .alignright,.wp-block-image.aligncenter,.wp-block-image.alignleft,.wp-block-image.alignright{display:table}.wp-block-image .aligncenter>figcaption,.wp-block-image .alignleft>figcaption,.wp-block-image .alignright>figcaption,.wp-block-image.aligncenter>figcaption,.wp-block-image.alignleft>figcaption,.wp-block-image.alignright>figcaption{caption-side:bottom;display:table-caption}.wp-block-image .alignleft{float:left;margin:.5em 1em .5em 0}.wp-block-image .alignright{float:right;margin:.5em 0 .5em 1em}.wp-block-image .aligncenter{margin-left:auto;margin-right:auto}.wp-block-image :where(figcaption){margin-bottom:1em;margin-top:.5em}.wp-block-image.is-style-circle-mask img{border-radius:9999px}@supports ((-webkit-mask-image:none) or (mask-image:none)) or (-webkit-mask-image:none){.wp-block-image.is-style-circle-mask img{border-radius:0;-webkit-mask-image:url('data:image/svg+xml;utf8,<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="50"/></svg>');mask-image:url('data:image/svg+xml;utf8,<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="50"/></svg>');mask-mode:alpha;-webkit-mask-position:center;mask-position:center;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-size:contain;mask-size:contain}}:root :where(.wp-block-image.is-style-rounded img,.wp-block-image .is-style-rounded img){border-radius:9999px}.wp-block-image figure{margin:0}.wp-lightbox-container{display:flex;flex-direction:column;position:relative}.wp-lightbox-container img{cursor:zoom-in}.wp-lightbox-container img:hover+button{opacity:1}.wp-lightbox-container button{align-items:center;backdrop-filter:blur(16px) saturate(180%);background-color:rgba(90,90,90,.25);border:none;border-radius:4px;cursor:zoom-in;display:flex;height:20px;justify-content:center;opacity:0;padding:0;position:absolute;right:16px;text-align:center;top:16px;width:20px;z-index:100}@media not (prefers-reduced-motion){.wp-lightbox-container button{transition:opacity .2s ease}}.wp-lightbox-container button:focus-visible{outline:3px auto rgba(90,90,90,.25);outline:3px auto -webkit-focus-ring-color;outline-offset:3px}.wp-lightbox-container button:hover{cursor:pointer;opacity:1}.wp-lightbox-container button:focus{opacity:1}.wp-lightbox-container button:focus,.wp-lightbox-container button:hover,.wp-lightbox-container button:not(:hover):not(:active):not(.has-background){background-color:rgba(90,90,90,.25);border:none}.wp-lightbox-overlay{box-sizing:border-box;cursor:zoom-out;height:100vh;left:0;overflow:hidden;position:fixed;top:0;visibility:hidden;width:100%;z-index:100000}.wp-lightbox-overlay .wp-lightbox-close-button{align-items:center;cursor:pointer;display:flex;font-family:inherit;gap:8px;justify-content:center;line-height:1;min-height:40px;min-width:40px;padding:0 4px;position:absolute;right:calc(env(safe-area-inset-right) + 16px);top:calc(env(safe-area-inset-top) + 16px);z-index:5000000}.wp-lightbox-overlay .wp-lightbox-close-button:focus,.wp-lightbox-overlay .wp-lightbox-close-button:hover,.wp-lightbox-overlay .wp-lightbox-close-button:not(:hover):not(:active):not(.has-background){background:none;border:none}.wp-lightbox-overlay .wp-lightbox-close-button:has(.wp-lightbox-close-text:not([hidden])) .wp-lightbox-close-icon svg{height:1em;width:1em}.wp-lightbox-overlay .wp-lightbox-close-icon svg{display:block}.wp-lightbox-overlay .wp-lightbox-navigation-button-next,.wp-lightbox-overlay .wp-lightbox-navigation-button-prev{align-items:center;bottom:16px;cursor:pointer;display:flex;font-family:inherit;gap:4px;justify-content:center;line-height:1;min-height:40px;min-width:40px;padding:0 8px;position:absolute;z-index:2000002}.wp-lightbox-overlay .wp-lightbox-navigation-button-next[hidden],.wp-lightbox-overlay .wp-lightbox-navigation-button-prev[hidden]{display:none}@media (min-width:960px){.wp-lightbox-overlay .wp-lightbox-navigation-button-next,.wp-lightbox-overlay .wp-lightbox-navigation-button-prev{bottom:50%;transform:translateY(-50%)}}.wp-lightbox-overlay .wp-lightbox-navigation-button-next:focus,.wp-lightbox-overlay .wp-lightbox-navigation-button-next:hover,.wp-lightbox-overlay .wp-lightbox-navigation-button-next:not(:hover):not(:active):not(.has-background),.wp-lightbox-overlay .wp-lightbox-navigation-button-prev:focus,.wp-lightbox-overlay .wp-lightbox-navigation-button-prev:hover,.wp-lightbox-overlay .wp-lightbox-navigation-button-prev:not(:hover):not(:active):not(.has-background){background:none;border:none;padding:0 8px}.wp-lightbox-overlay .wp-lightbox-navigation-button-next:has(.wp-lightbox-navigation-text:not([hidden])) .wp-lightbox-navigation-icon svg,.wp-lightbox-overlay .wp-lightbox-navigation-button-prev:has(.wp-lightbox-navigation-text:not([hidden])) .wp-lightbox-navigation-icon svg{display:block;height:1.5em;width:1.5em}.wp-lightbox-overlay .wp-lightbox-navigation-button-prev{left:calc(env(safe-area-inset-left) + 16px)}.wp-lightbox-overlay .wp-lightbox-navigation-button-next{right:calc(env(safe-area-inset-right) + 16px)}.wp-lightbox-overlay .wp-lightbox-navigation-icon svg{vertical-align:middle}.wp-lightbox-overlay .lightbox-image-container{height:var(--wp--lightbox-container-height);left:50%;overflow:hidden;position:absolute;top:50%;transform:translate(-50%,-50%);transform-origin:top left;width:var(--wp--lightbox-container-width);z-index:2000001}.wp-lightbox-overlay .wp-block-image{align-items:center;box-sizing:border-box;display:flex;height:100%;justify-content:center;margin:0;position:relative;transform-origin:0 0;width:100%;z-index:3000000}.wp-lightbox-overlay .wp-block-image img{height:var(--wp--lightbox-image-height);min-height:var(--wp--lightbox-image-height);min-width:var(--wp--lightbox-image-width);width:var(--wp--lightbox-image-width)}.wp-lightbox-overlay .wp-block-image figcaption{display:none}.wp-lightbox-overlay button{background:none;border:none}.wp-lightbox-overlay .scrim{background-color:#fff;height:100%;opacity:.9;position:absolute;width:100%;z-index:2000000}.wp-lightbox-overlay.active{visibility:visible}@media not (prefers-reduced-motion){.wp-lightbox-overlay.active{animation:turn-on-visibility .25s both}.wp-lightbox-overlay.active img{animation:turn-on-visibility .35s both}.wp-lightbox-overlay.show-closing-animation:not(.active){animation:turn-off-visibility .35s both}.wp-lightbox-overlay.show-closing-animation:not(.active) img{animation:turn-off-visibility .25s both}.wp-lightbox-overlay.zoom.active{animation:none;opacity:1;visibility:visible}.wp-lightbox-overlay.zoom.active .lightbox-image-container{animation:lightbox-zoom-in .4s}.wp-lightbox-overlay.zoom.active .lightbox-image-container img{animation:none}.wp-lightbox-overlay.zoom.active .scrim{animation:turn-on-visibility .4s forwards}.wp-lightbox-overlay.zoom.show-closing-animation:not(.active){animation:none}.wp-lightbox-overlay.zoom.show-closing-animation:not(.active) .lightbox-image-container{animation:lightbox-zoom-out .4s}.wp-lightbox-overlay.zoom.show-closing-animation:not(.active) .lightbox-image-container img{animation:none}.wp-lightbox-overlay.zoom.show-closing-animation:not(.active) .scrim{animation:turn-off-visibility .4s forwards}}@keyframes show-content-image{0%{visibility:hidden}99%{visibility:hidden}to{visibility:visible}}@keyframes turn-on-visibility{0%{opacity:0}to{opacity:1}}@keyframes turn-off-visibility{0%{opacity:1;visibility:visible}99%{opacity:0;visibility:visible}to{opacity:0;visibility:hidden}}@keyframes lightbox-zoom-in{0%{transform:translate(calc((-100vw + var(--wp--lightbox-scrollbar-width))/2 + var(--wp--lightbox-initial-left-position)),calc(-50vh + var(--wp--lightbox-initial-top-position))) scale(var(--wp--lightbox-scale))}to{transform:translate(-50%,-50%) scale(1)}}@keyframes lightbox-zoom-out{0%{transform:translate(-50%,-50%) scale(1);visibility:visible}99%{visibility:visible}to{transform:translate(calc((-100vw + var(--wp--lightbox-scrollbar-width))/2 + var(--wp--lightbox-initial-left-position)),calc(-50vh + var(--wp--lightbox-initial-top-position))) scale(var(--wp--lightbox-scale));visibility:hidden}}
/*# sourceURL=https://ritimus.com/wp-includes/blocks/image/style.min.css */
</style>
<style id="wp-block-paragraph-inline-css">
.is-small-text{font-size:.875em}.is-regular-text{font-size:1em}.is-large-text{font-size:2.25em}.is-larger-text{font-size:3em}.has-drop-cap:not(:focus):first-letter{float:left;font-size:8.4em;font-style:normal;font-weight:100;line-height:.68;margin:.05em .1em 0 0;text-transform:uppercase}body.rtl .has-drop-cap:not(:focus):first-letter{float:none;margin-left:.1em}p.has-drop-cap.has-background{overflow:hidden}:root :where(p.has-background){padding:1.25em 2.375em}:where(p.has-text-color:not(.has-link-color)) a{color:inherit}p.has-text-align-left[style*="writing-mode:vertical-lr"],p.has-text-align-right[style*="writing-mode:vertical-rl"]{rotate:180deg}
/*# sourceURL=https://ritimus.com/wp-includes/blocks/paragraph/style.min.css */
</style>
<style id="wp-block-library-inline-css-extra">
.has-text-align-justify{text-align:justify;}
/*# sourceURL=wp-block-library-inline-css */
</style>

<style id="classic-theme-styles-inline-css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>

<style id="global-styles-inline-css">
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}.wp-block-button{--wp--preset--dimension--25: 25%;--wp--preset--dimension--50: 50%;--wp--preset--dimension--75: 75%;--wp--preset--dimension--100: 100%;}:where(body) { margin: 0; }:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;font-style: inherit;font-weight: inherit;letter-spacing: inherit;line-height: inherit;padding-top: calc(0.667em + 2px);padding-right: calc(1.333em + 2px);padding-bottom: calc(0.667em + 2px);padding-left: calc(1.333em + 2px);text-decoration: none;text-transform: inherit;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
/*# sourceURL=global-styles-inline-css */
</style>

<link rel='stylesheet' id='contact-form-7-css' href='https://ritimus.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.5.6.1' media='all' />
<link rel='stylesheet' id='linear-css' href='https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/linearicons/linear.css?ver=2.8.8' media='all' />
<link rel='stylesheet' id='linear-icons-css' href='https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/nuxy/metaboxes/assets/css/linear-icons.css?ver=2.8.8' media='all' />
<link rel='stylesheet' id='font-awesome-min-css' href='https://ritimus.com/wp-content/themes/smarty/assets/fonts/font-awesome/css/font-awesome.min.css?ver=3.4.8' media='all' />
<link rel='stylesheet' id='ms-font-icomoon-css' href='https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/vendors/icomoon.fonts.css?ver=2.8.8' media='all' />
<link rel='stylesheet' id='stm_lms_icons-css' href='https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/icons/style.css?ver=2.8.8' media='all' />
<link rel='stylesheet' id='video.js-css' href='https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/vendors/video-js.min.css?ver=2.8.8' media='all' />
<link rel='stylesheet' id='masterstudy-lms-learning-management-system-css' href='https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/css/stm_lms.css?ver=1793883644' media='all' />
<link rel='stylesheet' id='stm-lms-noconflict/main-css' href='https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/css/parts/noconflict/main.css?ver=1' media='all' />
<link rel='stylesheet' id='timetable_sf_style-css' href='https://ritimus.com/wp-content/plugins/timetable/style/superfish.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='timetable_gtip2_style-css' href='https://ritimus.com/wp-content/plugins/timetable/style/jquery.qtip.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='timetable_style-css' href='https://ritimus.com/wp-content/plugins/timetable/style/style.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='timetable_event_template-css' href='https://ritimus.com/wp-content/plugins/timetable/style/event_template.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='timetable_responsive_style-css' href='https://ritimus.com/wp-content/plugins/timetable/style/responsive.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='timetable_font_lato-css' href='//fonts.googleapis.com/css?family=Lato:400,700&#038;ver=7.1.4' media='all' />
<style id="woocommerce-inline-inline-css">
.woocommerce form .form-row .required { visibility: visible; }
/*# sourceURL=woocommerce-inline-inline-css */
</style>
<link rel='stylesheet' id='stm-gdpr-styles-css' href='https://ritimus.com/wp-content/plugins/stm-gdpr-compliance/assets/css/styles.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='stm-fonts-css' href='https://fonts.googleapis.com/css?family=Quicksand%3A300%2C300i%2C400%2C400i%2C500%2C500i%2C600%2C600i%2C700%2C700i%2C800%2C800i%7CPatrick+Hand%3A400%2C400i%2C700&#038;subset=latin%2Clatin-ext' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='https://ritimus.com/wp-content/themes/smarty/assets/css/bootstrap.min.css?ver=3.4.8' media='all' />
<link rel='stylesheet' id='stm-icon-css' href='https://ritimus.com/wp-content/themes/smarty/assets/fonts/stm-icon/style.css?ver=3.4.8' media='all' />
<link rel='stylesheet' id='stm-select2-css' href='https://ritimus.com/wp-content/themes/smarty/assets/js/vendor/select2/css/select2.min.css?ver=3.4.8' media='all' />
<link rel='stylesheet' id='stm-skin-default-css' href='https://ritimus.com/wp-content/themes/smarty/assets/css/kindergarten-two/main.css?ver=3.4.8' media='all' />
<link rel='stylesheet' id='stm-style-css' href='https://ritimus.com/wp-content/themes/smarty/style.css?ver=3.4.8' media='all' />
<style id="stm-style-inline-css">
.header-mobile .logo {
    width: 164px;
    top: 6px;
    position: relative;

}

.post_view_list .entry-meta{
display:none;
}
.widget_footer.widget_nav_menu .menu > li {

float:none !important;
width:100% !important;
}

.widget_footer.widget_nav_menu .menu > li:nth-child(2n){
padding-left: 0px !important;
}
.widget-area.widget-area_type_footer > .row{
    display: flex !important;
    justify-content: space-between !important;
flex-wrap:wrap;

}

.widget-area.widget-area_type_footer > .row > div:nth-child(3){
    width: 16% ;
}
@media (max-width: 767px){

.widget-area_type_footer > .row .col-sm-6{
width :100% !important
}
}

.kurumsal {
    position: absolute;
    top: 25px;
    right: 180px;
 
}
.mr-2{
margin-right: 12px
}
/*# sourceURL=stm-style-inline-css */
</style>
<link rel='stylesheet' id='fancybox-css' href='https://ritimus.com/wp-content/themes/smarty/assets/js/vendor/fancybox/jquery.fancybox.css?ver=3.4.8' media='all' />
<link rel='stylesheet' id='stm-custom-fonts-css' href='//fonts.googleapis.com/css?family=Quicksand%3Aregular%2C700%2C300|Patrick+Hand%3Aregular&#038;ver=3.4.8' media='all' />
<link rel='stylesheet' id='jetpack_css-css' href='https://ritimus.com/wp-content/plugins/jetpack/css/jetpack.css?ver=10.9.3' media='all' />
<script id="jquery-core-js" src="https://ritimus.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1"></script>
<script id="jquery-migrate-js" src="https://ritimus.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1"></script>
<script id="vue.js-js" src="https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/nuxy/metaboxes/assets/js/vue.min.js?ver=2.8.8"></script>
<script id="vue-resource.js-js" src="https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/nuxy/metaboxes/assets/js/vue-resource.min.js?ver=2.8.8"></script>
<script id="vue2-datepicker-js" src="https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/nuxy/metaboxes/assets/js/vue2-datepicker.min.js?ver=2.8.8"></script>
<script id="stm-lms-lms-js-extra">
var stm_lms_vars = {"symbol":"$","position":"left","currency_thousands":",","wp_rest_nonce":"16ef261584"};
//# sourceURL=stm-lms-lms-js-extra
</script>
<script id="stm-lms-lms-js" src="https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/js/lms.js?ver=1"></script>
<script id="stm-lms-noconflict/main-js" src="https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/js/noconflict/main.js?ver=1"></script>
<script id="jquery-blockui-js" src="https://ritimus.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.6.5.2"></script>
<script id="wc-add-to-cart-js-extra">
var wc_add_to_cart_params = {"ajax_url":"/wp-admin/admin-ajax.php","wc_ajax_url":"/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https://ritimus.com/cart/","is_cart":"","cart_redirect_after_add":"no"};
//# sourceURL=wc-add-to-cart-js-extra
</script>
<script id="wc-add-to-cart-js" src="https://ritimus.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=6.5.2"></script>
<script id="vc_woocommerce-add-to-cart-js-js" src="https://ritimus.com/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=6.7.0"></script>
<script defer id="woocommerce-analytics-js" src="https://stats.wp.com/s-202645.js"></script>
<link rel="https://api.w.org/" href="https://ritimus.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://ritimus.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 7.1.4" />
<meta name="generator" content="WooCommerce 6.5.2" />
<style>

/* CSS added by Hide Metadata Plugin */

.entry-meta .byline,
			.entry-meta .by-author,
			.entry-header .entry-meta > span.byline,
			.entry-meta .author.vcard {
				display: none;
			}
.entry-meta .posted-on,
			.entry-header .entry-meta > span.posted-on {
				display: none;
			}</style>
    <script>
        var stm_lms_pro_nonces = {"stm_lms_pro_install_base":"2c1c86d2e2","stm_lms_pro_search_courses":"9d70db1616","stm_lms_pro_udemy_import_courses":"a5ece313ba","stm_lms_pro_udemy_publish_course":"b316795360","stm_lms_pro_udemy_import_curriculum":"df1f05f900","stm_lms_pro_save_addons":"6bb4d94a1f","stm_lms_create_announcement":"479b579c1f","stm_lms_pro_upload_image":"71484f741d","stm_lms_pro_get_image_data":"2190330ec3","stm_lms_pro_save_quiz":"f2552138ca","stm_lms_pro_save_lesson":"bc4342eb78","stm_lms_pro_save_front_course":"1cabe19652","stm_lms_get_course_info":"61d6c1d9db","stm_lms_get_course_students":"88d82bd2a7","stm_lms_change_post_status":"b0c75a237e"};
    </script>
    	<script type="text/javascript">
		var stm_lms_ajaxurl = 'https://ritimus.com/wp-admin/admin-ajax.php';
		var stm_lms_resturl = 'https://ritimus.com/wp-json/stm-lms/v1';
	</script>

	<style>
		.vue_is_disabled {
			display: none;
		}
	</style>
		<script>
		var stm_lms_nonces = {"load_modal":"a7e4718584","load_content":"2533178d95","start_quiz":"3fdad9d8d6","user_answers":"aebc2d8a26","get_order_info":"dedb20d9ad","user_orders":"1d86a048b8","stm_lms_get_instructor_courses":"5ff7ebc3f9","stm_lms_add_comment":"7fe0f3b790","stm_lms_get_comments":"9f89420032","stm_lms_login":"f34cfd72a0","stm_lms_register":"b73f8984bc","stm_lms_become_instructor":"c06add65cf","stm_lms_enterprise":"3a0928c533","stm_lms_get_user_courses":"97a8d6c5d0","stm_lms_get_user_quizzes":"bd5e636aef","stm_lms_wishlist":"53e37ce0de","stm_lms_save_user_info":"9373de2f45","stm_lms_lost_password":"fc6b97897b","stm_lms_change_avatar":"76efdde163","stm_lms_delete_avatar":"30082ec2ee","stm_lms_complete_lesson":"88553a01d2","stm_lms_use_membership":"c6b89a4aaf","stm_lms_change_featured":"66b0706017","stm_lms_delete_course_subscription":"ea5aeb1852","stm_lms_get_reviews":"cd4d21f881","stm_lms_add_review":"0e05423561","stm_lms_add_to_cart":"9dc1a59fe3","stm_lms_delete_from_cart":"af17b92841","stm_lms_purchase":"a80836da1d","stm_lms_send_message":"129571588d","stm_lms_get_user_conversations":"d5f0fc652b","stm_lms_get_user_messages":"15c1748356","stm_curriculum":"d9a764b668","stm_manage_posts":"af18b387da","stm_curriculum_create_item":"487186ab8b","stm_curriculum_get_item":"b68831e1ab","stm_save_questions":"d78bee6ef1","stm_lms_terms":"371644b828","stm_lms_questions":"6abd7cbdf3","stm_lms_create_term":"6b1792aed8","stm_save_title":"2d02d83030","wpcfto_save_settings":"5d8288237a","stm_lms_tables_update":"fe4edf0a42","stm_lms_get_enterprise_groups":"6439291e16","stm_lms_get_enterprise_group":"e99441358d","stm_lms_add_enterprise_group":"8bfd498ac1","stm_lms_delete_enterprise_group":"874be9e39d","stm_lms_add_to_cart_enterprise":"f3f74151c7","stm_lms_get_user_ent_courses":"9fac7dc6e7","stm_lms_delete_user_ent_courses":"3449029ce7","stm_lms_add_user_ent_courses":"9b2344b6ca","stm_lms_change_ent_group_admin":"f286476a54","stm_lms_delete_user_from_group":"80fccb2ed7","stm_lms_import_groups":"caaf851cb0","stm_lms_upload_file_assignment":"297a75dfdb","stm_lms_delete_assignment_file":"532a45b6a6","stm_lms_save_draft_content":"31a26eec27","stm_lms_accept_draft_assignment":"65e6229f31","stm_lms_get_assignment_data":"07854b2d69","stm_lms_get_instructor_assingments":"7203c3281e","stm_lms_get_user_assingments":"49948c7322","stm_lms_edit_user_answer":"1bf7345eb0","stm_lms_get_user_points_history":"69e3d96eb4","stm_lms_buy_for_points":"c8dd153103","stm_lms_get_point_users":"3e518e691e","stm_lms_get_user_points_history_admin":"50edf8911e","stm_lms_change_points":"a150f27dbe","stm_lms_delete_points":"8eaef27340","stm_lms_get_user_bundles":"e54d5fc11b","stm_lms_change_bundle_status":"c7638df165","stm_lms_delete_bundle":"0e24169096","stm_lms_get_co_courses":"2fdbe3aeb5","stm_lms_check_certificate_code":"77a88b9178","stm_lms_get_google_classroom_courses":"e111689c5a","stm_lms_get_google_classroom_course":"7c5e930e4b","stm_lms_get_google_classroom_publish_course":"fe5c1c6e97","stm_lms_get_g_c_get_archive_page":"6ff5f6ab78","install_zoom_addon":"345638a831","stm_lms_get_course_cookie_redirect":"97f7e11ec0","stm_get_certificates":"506307daab","stm_get_certificate_fields":"f4805a3acc","stm_save_certificate":"046c099371","stm_get_certificate_categories":"9e5f96def9","stm_get_certificate":"7f3383291a","stm_delete_certificate":"f81a9e5405","stm_lms_get_users_submissions":"96761669b7","stm_lms_update_user_status":"3186249837","stm_lms_hide_become_instructor_notice":"9ac8fe21f6","stm_lms_ban_user":"fec8209c9d","stm_lms_save_forms":"cc3605890f","stm_lms_get_forms":"c922dd6c40","stm_lms_upload_form_file":"93cea2fad5","stm_lms_dashboard_get_course_students":"5963c05a3f","stm_lms_dashboard_delete_user_from_course":"8713d91582","stm_lms_dashboard_add_user_to_course":"02201c524d","stm_lms_add_to_cart_guest":"8a50f5053e","stm_lms_fast_login":"42e7e45122","stm_lms_fast_register":"2a5058f3b9","stm_lms_change_lms_author":"1d0aee9ed2","stm_lms_add_student_manually":"d76e908d01","stm_lms_change_course_status":"67ab656db0","stm_lms_total_progress":"6df16f6a89","stm_lms_add_h5p_result":"1df077a6b9","stm_lms_toggle_buying":"4b065c4d75","stm_lms_logout":"140beb79de","stm_lms_restore_password":"7f03ce370d","stm_lms_hide_announcement":"d5bd161cbb","stm_lms_get_curriculum_v2":"ed9bd156cb","stm_lms_dashboard_get_student_progress":"d6b47af795","stm_lms_dashboard_set_student_item_progress":"bebb5586f0","stm_lms_dashboard_reset_student_progress":"4ae1bc4f5c","stm_lms_dashboard_get_courses_list":"891dd979fb","stm_lms_dashboard_get_student_assignments":"1951d33895","stm_lms_dashboard_get_student_quizzes":"2ab64e3fe9","stm_lms_dashboard_get_student_quiz":"f8b4709bc2","stm_lms_wizard_save_settings":"caecd17fd4","stm_lms_wizard_save_business_type":"2a664b68f2","stm_lms_get_enrolled_assingments":"8c90624c18"};
	</script>
		<script type="text/javascript">
		var stm_wpcfto_ajaxurl = 'https://ritimus.com/wp-admin/admin-ajax.php';
	</script>

	<style>
		.vue_is_disabled {
			display: none;
		}
	</style>
		<script>
		var stm_wpcfto_nonces = {"wpcfto_save_settings":"5d8288237a","get_image_url":"ec579844db","wpcfto_upload_file":"b5e0dea63f","wpcfto_search_posts":"e243e97e38"};
	</script>
	<style type='text/css'>img#wpstats{display:none}</style>
	<script type="text/javascript">window.wp_data = {"ajax_url":"https:\/\/ritimus.com\/wp-admin\/admin-ajax.php","is_mobile":false,"load_meal":"5595e5caf4","review_status":"f90b72973b"};</script>        <script type="text/javascript">
            var smarty_install_plugin = 'ea18f58f4b';
        </script>
        	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
			<style>
			#wp-admin-bar-stm_lms_settings			img {
				max-width: 25px;
				vertical-align: top;
				position: relative;
				top: 3px;
			}
		</style>
		<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 6.5.5 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://ritimus.com/wp-content/uploads/2022/06/cropped-favicon-32x32-1-32x32.png" sizes="32x32" />
<link rel="icon" href="https://ritimus.com/wp-content/uploads/2022/06/cropped-favicon-32x32-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://ritimus.com/wp-content/uploads/2022/06/cropped-favicon-32x32-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://ritimus.com/wp-content/uploads/2022/06/cropped-favicon-32x32-1-270x270.png" />
<script type="text/javascript">function setREVStartSize(e){
			//window.requestAnimationFrame(function() {				 
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
				try {								
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
					if(e.layout==="fullscreen" || e.l==="fullscreen") 						
						newh = Math.max(e.mh,window.RSIH);					
					else{					
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,						
							sl;					
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];									
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}
					var el = document.getElementById(e.c);
					if (el!==null && el) el.style.height = newh+"px";					
					el = document.getElementById(e.c+"_wrapper");
					if (el!==null && el) {
						el.style.height = newh+"px";
						el.style.display = "block";
					}
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}					   
			//});
		  };</script>
<style type="text/css" title="dynamic-css" class="options-output">.header .logo{max-width:186px;}body{font-family:Quicksand;}body{font-size:16px;}body{line-height:26px;}h1,.h1{font-family:Patrick Hand;}</style>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><link rel='stylesheet' id='rs-plugin-settings-css' href='https://ritimus.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.5.5' media='all' />
<style id="rs-plugin-settings-inline-css">
#rs-demo-id {}
/*# sourceURL=rs-plugin-settings-inline-css */
</style>

</head>
<body class="error404 wp-theme-smarty stm_lms_button theme-smarty woocommerce-no-js wpb-js-composer js-comp-ver-6.7.0 vc_responsive">
<div id="wrapper">

	

<div class="header-holder header-holder_view-style_1 ">

    

<header id="masthead" class="header header_view-style_1">
    <div class="container">
        <div class="header__content">
            <!-- Logo -->
                            <a href="https://ritimus.com/" class="logo" title="Ritimus"><img src="https://ritimus.com/wp-content/uploads/2022/06/RitimusLogo.png" alt="Ritimus"></a>
            
            
            
            <div class="nav_menu_indent"></div>

            <div class="stm-nav stm-nav_type_header"><ul id="header-nav-menu" class="stm-nav__menu stm-nav__menu_type_header"><li id="menu-item-5154" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-5154"><a href="https://ritimus.com/">Anasayfa</a></li>
<li id="menu-item-5048" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5048"><a href="https://ritimus.com/about/">Hakkımızda</a></li>
<li id="menu-item-5156" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5156"><a href="https://ritimus.com/akademik/">Akademik</a></li>
<li id="menu-item-5162" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-5162"><a href="https://ritimus.com/blog/">Blog</a></li>
<li id="menu-item-5206" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5206"><a href="https://ritimus.com/gallery/">Galeri</a></li>
<li id="menu-item-5112" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5112"><a href="https://ritimus.com/satin-alma/">Satın Alma</a></li>
<li id="menu-item-5311" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5311"><a href="https://ritimus.com/oyunlar/">Oyunlar</a></li>
<li id="menu-item-5310" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5310"><a href="https://ritimus.com/kurumsal/">Kurumsal</a></li>
<li id="menu-item-5047" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5047"><a href="https://ritimus.com/contacts/">İletişim</a></li>
</ul></div>
        </div><!-- /header__content -->
    </div><!-- /container -->
</header><!-- /header -->

<!-- Mobile - Top Bar -->
<div class="top-bar-mobile">
    
    </div><!-- /top-bar-mobile -->

<!-- Mobile - Header -->
<div class="header-mobile">
    <div class="header-mobile__logo">
                    <a href="https://ritimus.com/" class="logo" title="Ritimus"><img src="https://ritimus.com/wp-content/uploads/2022/06/RitimusLogo.png" alt="Ritimus"></a>
                <div class="header-mobile__nav-control">
            <span class="header-mobile__control-line"></span>
        </div>
    </div><!-- /header-mobile__logo -->

    <div class="stm-nav stm-nav_type_mobile-header"><ul id="header-mobile-nav-menu" class="stm-nav__menu stm-nav__menu_type_mobile-header"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-5154"><a href="https://ritimus.com/">Anasayfa</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5048"><a href="https://ritimus.com/about/">Hakkımızda</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5156"><a href="https://ritimus.com/akademik/">Akademik</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-5162"><a href="https://ritimus.com/blog/">Blog</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5206"><a href="https://ritimus.com/gallery/">Galeri</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5112"><a href="https://ritimus.com/satin-alma/">Satın Alma</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5311"><a href="https://ritimus.com/oyunlar/">Oyunlar</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5310"><a href="https://ritimus.com/kurumsal/">Kurumsal</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5047"><a href="https://ritimus.com/contacts/">İletişim</a></li>
</ul></div></div><!-- /header-mobile -->
    
</div><!-- /.header-holder -->
<div class="content stm-border_color_pink" >
    <div class="container">
        <main class="main">
            <section class="error-404 not-found">
                <!-- Logo -->
                                    <div class="logo_box">
                        <a href="https://ritimus.com/" class="logo"
                           title="Ritimus"><img src="https://ritimus.com/wp-content/uploads/2022/06/RitimusLogo.png"
                                                                          alt="Logo"></a>
                    </div>
                                <h1>Error 404: Page not found</h1>
                <p>We&#039;re sorry, but the page you requested can&#039;t be found.</p>
                <p><a href="https://ritimus.com/"
                      class="stm-btn stm-btn_flat stm-btn_orange stm-btn_md stm-btn_icon-right">Homepage</a>
                </p>
            </section><!-- /error-404 -->
        </main><!-- /main -->
    </div>
    

	
	<footer id="colophon" class="footer footer_type_default">
		<div class="container">

								<div class="widget-area widget-area_type_footer">
						<div class="row">
															<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
									<div id="text-2" class="widget widget_footer widget_text">			<div class="textwidget"><p><a href="/kindergarten-two/"><img loading="lazy" decoding="async" class="alignnone size-medium wp-image-5240" src="https://ritimus.com/wp-content/uploads/2022/06/LOGO_PNG_Calisma-Yuzeyi-1-300x107.png" alt="" width="300" height="107" srcset="https://ritimus.com/wp-content/uploads/2022/06/LOGO_PNG_Calisma-Yuzeyi-1-300x107.png 300w, https://ritimus.com/wp-content/uploads/2022/06/LOGO_PNG_Calisma-Yuzeyi-1.png 400w" sizes="auto, (max-width: 300px) 100vw, 300px" /></a><strong>Eğitici zeka oyunları RitimUS&#8217;u Google Play ve App Store&#8217;dan ücretsiz bir şekilde indirip oynamaya başlayın.</strong></p>
</div>
		</div>								</div>
															<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
									<div id="stm_widget_contact_details-2" class="widget widget_footer widget_contact-details"><h4 class="widget_title">İletişim</h4>
			<ul class="list list_unstyle list_contact-details">

																						<li class="list__item list__item_address">Balmumcu Mah, Bestekar Şevki Bey Sk. No:26/2, 34349 Beşiktaş/İstanbul
</li>
																																	<li class="list__item list__item_telephone">02122742121</li>
																																										<li class="list__item list__item_email"><a href="mailto:destek@ritimus.com">destek@ritimus.com</a></li>
																																	<li class="list__item list__item_schedule">Pazartesi — Cuma: 9.00 — 17.00</li>
															
			</ul>

		</div><div id="block-18" class="widget widget_footer widget_block widget_text">
<p class="wp-block-paragraph"></p>
</div>								</div>
															<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
									<div id="nav_menu-2" class="widget widget_footer widget_nav_menu"><h4 class="widget_title">Hızlı Erişim</h4><div class="menu-about-container"><ul id="menu-about" class="menu"><li id="menu-item-5354" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-5354"><a href="https://ritimus.com/">Anasayfa</a></li>
<li id="menu-item-5355" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5355"><a href="https://ritimus.com/about/">Hakkımızda</a></li>
<li id="menu-item-5356" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5356"><a href="https://ritimus.com/gallery/">Galeri</a></li>
<li id="menu-item-5357" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5357"><a href="https://ritimus.com/satin-alma/">Satın Alma</a></li>
<li id="menu-item-5353" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5353"><a href="https://ritimus.com/contacts/">İletişim</a></li>
</ul></div></div>								</div>
															<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
									<div id="block-16" class="widget widget_footer widget_block">
<h4 class="widget_title wp-block-heading">ŞİMDİ İNDİR</h4>
</div><div id="block-8" class="widget widget_footer widget_block widget_media_image">
<figure class="wp-block-image size-medium is-resized"><a href="https://apps.apple.com/tr/app/ritimus/id1574950058?l=tr"><img loading="lazy" decoding="async" src="https://ritimus.com/wp-content/uploads/2022/06/Layer-2-300x98.png" alt="" class="wp-image-5348" width="124" height="40" srcset="https://ritimus.com/wp-content/uploads/2022/06/Layer-2-300x98.png 300w, https://ritimus.com/wp-content/uploads/2022/06/Layer-2-1024x336.png 1024w, https://ritimus.com/wp-content/uploads/2022/06/Layer-2-768x252.png 768w, https://ritimus.com/wp-content/uploads/2022/06/Layer-2-1536x504.png 1536w, https://ritimus.com/wp-content/uploads/2022/06/Layer-2-1320x433.png 1320w, https://ritimus.com/wp-content/uploads/2022/06/Layer-2-600x197.png 600w, https://ritimus.com/wp-content/uploads/2022/06/Layer-2.png 1540w" sizes="auto, (max-width: 124px) 100vw, 124px" /></a></figure>
</div><div id="block-9" class="widget widget_footer widget_block widget_media_image">
<figure class="wp-block-image size-medium is-resized"><a href="https://play.google.com/store/apps/details?id=com.ritimus.ritimus"><img loading="lazy" decoding="async" src="https://ritimus.com/wp-content/uploads/2022/06/Layer-1-300x98.png" alt="" class="wp-image-5349" width="124" height="40" srcset="https://ritimus.com/wp-content/uploads/2022/06/Layer-1-300x98.png 300w, https://ritimus.com/wp-content/uploads/2022/06/Layer-1-1024x335.png 1024w, https://ritimus.com/wp-content/uploads/2022/06/Layer-1-768x251.png 768w, https://ritimus.com/wp-content/uploads/2022/06/Layer-1-1536x503.png 1536w, https://ritimus.com/wp-content/uploads/2022/06/Layer-1-1320x432.png 1320w, https://ritimus.com/wp-content/uploads/2022/06/Layer-1-600x196.png 600w, https://ritimus.com/wp-content/uploads/2022/06/Layer-1.png 1540w" sizes="auto, (max-width: 124px) 100vw, 124px" /></a></figure>
</div>								</div>
													</div>
					</div>
			
											<div class="copyright">Copyright © RitimUS </div>
			
		</div>
	</footer><!-- /.footer -->


</div><!-- /Wrapper -->



		<script type="text/javascript">
			window.RS_MODULES = window.RS_MODULES || {};
			window.RS_MODULES.modules = window.RS_MODULES.modules || {};
			window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
			window.RS_MODULES.defered = true;
			window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
			window.RS_MODULES.type = 'compiled';
		</script>
		<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/smarty/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<script id="masterstudy-bootstrap-js" src="https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/vendors/bootstrap.min.js?ver=2.8.8"></script>
<script id="masterstudy-bootstrap-custom-js" src="https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/vendors/ms-bootstrap-custom.js?ver=2.8.8"></script>
<script id="wp-polyfill-js" src="https://ritimus.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0"></script>
<script id="contact-form-7-js-extra">
var wpcf7 = {"api":{"root":"https://ritimus.com/wp-json/","namespace":"contact-form-7/v1"},"cached":"1"};
//# sourceURL=contact-form-7-js-extra
</script>
<script id="contact-form-7-js" src="https://ritimus.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.5.6.1"></script>
<script id="lms_countdown.js-js" src="https://ritimus.com/wp-content/plugins/masterstudy-lms-learning-management-system/assets/js/countdown.js?ver=2.8.8"></script>
<script defer async id="tp-tools-js" src="https://ritimus.com/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.5.5"></script>
<script defer async id="revmin-js" src="https://ritimus.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.5.5"></script>
<script id="jquery-ui-core-js-before">
jQuery.uiBackCompat = true;
//# sourceURL=jquery-ui-core-js-before
</script>
<script id="jquery-ui-core-js" src="https://ritimus.com/wp-includes/js/jquery/ui/core.min.js?ver=1.14.2"></script>
<script id="jquery-ui-tabs-js" src="https://ritimus.com/wp-includes/js/jquery/ui/tabs.min.js?ver=1.14.2"></script>
<script id="jquery-qtip2-js" src="https://ritimus.com/wp-content/plugins/timetable/js/jquery.qtip.min.js?ver=7.1.4"></script>
<script id="jquery-ba-bqq-js" src="https://ritimus.com/wp-content/plugins/timetable/js/jquery.ba-bbq.min.js?ver=7.1.4"></script>
<script id="jquery-carouFredSel-js" src="https://ritimus.com/wp-content/plugins/timetable/js/jquery.carouFredSel-6.2.1-packed.js?ver=7.1.4"></script>
<script id="timetable_main-js-extra">
var tt_config = [];
tt_config = {"ajaxurl":"https:\/\/ritimus.com\/wp-admin\/admin-ajax.php"};;
//# sourceURL=timetable_main-js-extra
</script>
<script id="timetable_main-js" src="https://ritimus.com/wp-content/plugins/timetable/js/timetable.js?ver=7.1.4"></script>
<script id="js-cookie-js" src="https://ritimus.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.6.5.2"></script>
<script id="woocommerce-js-extra">
var woocommerce_params = {"ajax_url":"/wp-admin/admin-ajax.php","wc_ajax_url":"/?wc-ajax=%%endpoint%%"};
//# sourceURL=woocommerce-js-extra
</script>
<script id="woocommerce-js" src="https://ritimus.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=6.5.2"></script>
<script id="wc-cart-fragments-js-extra">
var wc_cart_fragments_params = {"ajax_url":"/wp-admin/admin-ajax.php","wc_ajax_url":"/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_8f5c8abd69971390d2ffedc8cbea7ef3","fragment_name":"wc_fragments_8f5c8abd69971390d2ffedc8cbea7ef3","request_timeout":"5000"};
//# sourceURL=wc-cart-fragments-js-extra
</script>
<script id="wc-cart-fragments-js" src="https://ritimus.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=6.5.2"></script>
<script id="wc-cart-fragments-js-after">
		jQuery( 'body' ).bind( 'wc_fragments_refreshed', function() {
			var jetpackLazyImagesLoadEvent;
			try {
				jetpackLazyImagesLoadEvent = new Event( 'jetpack-lazy-images-load', {
					bubbles: true,
					cancelable: true
				} );
			} catch ( e ) {
				jetpackLazyImagesLoadEvent = document.createEvent( 'Event' )
				jetpackLazyImagesLoadEvent.initEvent( 'jetpack-lazy-images-load', true, true );
			}
			jQuery( 'body' ).get( 0 ).dispatchEvent( jetpackLazyImagesLoadEvent );
		} );
		
//# sourceURL=wc-cart-fragments-js-after
</script>
<script id="stm-gdpr-scripts-js-extra">
var stm_gdpr_vars = {"AjaxUrl":"https://ritimus.com/wp-admin/admin-ajax.php","error_prefix":"","success":""};
//# sourceURL=stm-gdpr-scripts-js-extra
</script>
<script id="stm-gdpr-scripts-js" src="https://ritimus.com/wp-content/plugins/stm-gdpr-compliance/assets/js/scripts.js?ver=7.1.4"></script>
<script id="bootstrap-js" src="https://ritimus.com/wp-content/themes/smarty/assets/js/vendor/bootstrap.min.js?ver=3.4.8"></script>
<script id="stm-select2-js" src="https://ritimus.com/wp-content/themes/smarty/assets/js/vendor/select2/js/select2.min.js?ver=3.4.8"></script>
<script id="stm-custom-js" src="https://ritimus.com/wp-content/themes/smarty/assets/js/custom.js?ver=3.4.8"></script>
<script id="fancybox-js" src="https://ritimus.com/wp-content/themes/smarty/assets/js/vendor/fancybox/jquery.fancybox.pack.js?ver=3.4.8"></script>
<!-- start Simple Custom CSS and JS -->
<script type="text/javascript">
 

var footer = document.getElementsByClassName("copyright")
var div = document.createElement("div")

let arr = [
    {text: "Privacy Policy" , link:"https://ritimus.com/privacy-policy" },
    {text: "Distance Sales Agreement" , link:"https://ritimus.com/distance-sales-agreement" },
    {text: "Preliminary Information Form" , link:"https://ritimus.com/preliminary-information-form" },

]

for (let index = 0; index < arr.length; index++) {
   
    var a = document.createElement("a")
    a.href = arr[index].link
    a.innerText = arr[index].text
    if (index != arr.length -1) {
        a.classList.add("mr-2")
    }
   
    div.appendChild(a)
    
}

footer[0].appendChild(div)
</script>
<!-- end Simple Custom CSS and JS -->
<script src='https://stats.wp.com/e-202645.js' defer></script>
<script>
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:10.9.3',blog:'207654119',post:'0',tz:'0',srv:'ritimus.com'} ]);
	_stq.push([ 'clickTrackerInit', '207654119', '0' ]);
</script>
</body>
</html></div><!-- /content -->
<!-- Page generated by LiteSpeed Cache 4.4.3 on 2026-11-05 13:00:44 -->